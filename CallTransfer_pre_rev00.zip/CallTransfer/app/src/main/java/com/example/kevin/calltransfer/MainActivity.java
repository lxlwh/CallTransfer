package com.example.kevin.calltransfer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

//    MyMissedCall mymissedcall;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button_home1 = findViewById(R.id.text_test);
        Button button_home2 = findViewById(R.id.calllog_view);
        Button button_calltest = findViewById(R.id.button_calltest);

        button_home2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CallLog_view.class);
                startActivity(intent);
            }
        });

        button_home1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Text_test.class);
                startActivity(intent);
            }
        });

 /*       final IntentFilter Misscallfilter = new IntentFilter();
        Misscallfilter.addAction("com.android.phone.NotificationMgr.MissedCall_intent");
        mymissedcall = new MyMissedCall();
        registerReceiver(mymissedcall, Misscallfilter);*/

        button_calltest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent("com.example.kevin.calltransfer.MYI");
                sendBroadcast(intent);
            }
        });
    }



 /*   @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(mymissedcall);
    }*/

}

/*class MyMissedCall extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent){
        Toast.makeText(context, "You got a missed call", Toast.LENGTH_LONG).show();
    }
}*/